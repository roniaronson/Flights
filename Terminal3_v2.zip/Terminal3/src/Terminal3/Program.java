package Terminal3;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Program {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner scan = new Scanner(System.in);
		Scanner scanFile = new Scanner("Terminal3.txt");
		PrintWriter pw = new PrintWriter("Terminal3.txt");
		TimeTable terminal3 = new TimeTable();

		boolean exitCase = false;

		while (exitCase == false) {
			System.out.println(
					"Enter your choise: \n1-Enter new flight details \n2-Show all departures details \n3-Show all arrivals details \n4-Save flights details \n5-Import from file \n6-Show by destination \n7-Show by origin \n8-Show by dates \n-1-Exit");
			int choice = scan.nextInt();
			switch (choice) {
			case 1:
				terminal3.addFlight(new Flight(scan));
				break;
			case 2:
				System.out.println(terminal3.showDeparturesFlights());
				break;
			case 3:
				System.out.println(terminal3.showArrivalsFlights());
				break;
			case 4:
				terminal3.save(pw);
				break;
			case 5:
				terminal3.importFlights(scanFile);
				break;
			case 6:
				System.out.println("enter destination");
				System.out.println(terminal3.showByDestination(scan.next()));
				break;
			case 7:
				System.out.println("enter origin");
				System.out.println(terminal3.showByOrigin(scan.next()));
				break;
			case 8:
				System.out.println("Search from:(enter date)");
				MyDate startDate = new MyDate(scan);
				System.out.println("Search to:(enter date)");
				MyDate endDate = new MyDate(scan);
				System.out.println(terminal3.findByDate(startDate, endDate));
			case -1:
				exitCase = true;
				break;
			}
		}
	}
}
