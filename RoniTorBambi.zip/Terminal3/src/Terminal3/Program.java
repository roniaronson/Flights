package Terminal3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Program {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner scan = new Scanner(System.in);
		String filename2=("C:\\Users\\User\\Desktop\\read.txt");//import

		String filename="C:\\Users\\User\\Desktop\\roni.txt";//export

		
		TimeTable terminal3 = new TimeTable();
		Flight london = createFlight1();
		Flight newYork = createFlight2();
		
		terminal3.addFlight(newYork);
		terminal3.addFlight(london);
		boolean exitCase = false;

		while (exitCase == false) {
			System.out.println(
					"Enter your choise: \n1-Enter new flight details \n2-Show all departures details \n3-Show all arrivals details \n4-Save flights details \n5-Import from file \n6-Show by destination \n7-Show by origin \n8-Show by dates \n-1-Exit");
			int choice = scan.nextInt();
			switch (choice) {
			case 1:
				terminal3.addFlight(new Flight(scan));
				break;
			case 2:
				System.out.println(terminal3.showDeparturesFlights());
				break;
			case 3:
				System.out.println(terminal3.showArrivalsFlights());
				break;
			case 4:
				terminal3.save(filename);
				break;
			case 5:
				terminal3.importFlights(filename2);
				break;
			case 6:
				System.out.println("enter destination");
				System.out.println(terminal3.showByDestination(scan.next()));
				break;
			case 7:
				System.out.println("enter origin");
				System.out.println(terminal3.showByOrigin(scan.next()));
				break;
			case 8:
				System.out.println("Search from:(enter date)");
				System.out.println("Enter year: ");
				int year= scan.nextInt();
				System.out.println("Enter month: ");
				int month=scan.nextInt();
				System.out.println("Enter day: ");
				int day= scan.nextInt();
				System.out.println("Enter hour: ");
				int hour=scan.nextInt();
				System.out.println("Enter minute: ");
				int minute=scan.nextInt();
				LocalDateTime startDate =LocalDateTime.of(year, month, day, hour, minute);
				System.out.println("Search to:(enter date)");
				System.out.println("Enter year: ");
				 year= scan.nextInt();
				System.out.println("Enter month: ");
				 month=scan.nextInt();
				System.out.println("Enter day: ");
				 day= scan.nextInt();
				System.out.println("Enter hour: ");
				 hour=scan.nextInt();
				System.out.println("Enter minute: ");
				 minute=scan.nextInt();
				LocalDateTime endDate =LocalDateTime.of(year, month, day, hour, minute);
				System.out.println(terminal3.findByDate(startDate, endDate));
			case -1:
				exitCase = true;
				break;
			}
		}
		
	}
	private static Flight createFlight1()  {
		LocalDateTime londonDateArrival = LocalDateTime.of(2020,5,20,10,10);
		LocalDateTime londonDateDeparture = LocalDateTime.of(2020,5,20,00,10);
		Flight london = new Flight("LY315", "London", "Israel", "El-Al", londonDateArrival, londonDateDeparture, "onTime");
		return london;

	}

	private static Flight createFlight2()  {
		LocalDateTime newYorkDateArrival = LocalDateTime.of(2020,4,20,12,10);
		LocalDateTime newYorkDateDeparture = LocalDateTime.of(2020,4,20,00,10);
		Flight newYork = new Flight("LY3001", "NewYork", "Israel", "El-Al", newYorkDateArrival, newYorkDateDeparture, "onTime");
		System.out.println(newYork.toString());
		return newYork;
	}
}
