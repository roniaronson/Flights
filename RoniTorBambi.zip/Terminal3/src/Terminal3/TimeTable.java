package Terminal3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.Scanner;
import java.util.Vector;

public class TimeTable {

	private Vector <Flight> allFlights = new Vector <Flight>();
	private Vector <Flight> allArrivals = new Vector <Flight>();
	private Vector <Flight> allDeparture = new Vector <Flight>();


	public TimeTable() {
	}

	public TimeTable(Scanner scan, boolean t) {
		int counter = scan.nextInt();
		for (int i = 0; i < counter; i++) {
			Flight newFlight = new Flight(scan, t);
			addFlight(newFlight);
		}
	}

	public void addFlight(Flight newFlight) {
		int counter=0;
		if(newFlight.getType().equalsIgnoreCase("Arrival")) {
			counter=allArrivals.size();
			while(counter!=0&&newFlight.getArrival().isBefore(allArrivals.get(counter-1).getArrival())) {
					counter--;
				}
			allArrivals.add(counter, newFlight);
			}
		else {
			counter=allDeparture.size();
			//System.out.println(counter);
			while(counter!=0&&newFlight.getDeparture().isBefore(allDeparture.get(counter-1).getDeparture())) {
					counter--;
				}
			allDeparture.add(counter, newFlight);
		}
		counter=allFlights.size();
		while(counter!=0&&newFlight.getDeparture().isBefore(allFlights.get(counter-1).getDeparture())) {
			counter--;
		}
		allFlights.add(counter, newFlight);
	}

	
	public String showDeparturesFlights() {	
		StringBuffer allFlightss = new StringBuffer("");
		if(allDeparture.size()==0)
			return "null";
		else {for (int j = 0; j < allDeparture.size(); j++) {
			allFlightss.append(allDeparture.elementAt(j).toString());
		}		
		return allFlightss.toString();
	}
	}

	public String showArrivalsFlights() {
		StringBuffer allFlightss = new StringBuffer("");
		for (int j = 0; j < allArrivals.size(); j++) {
			allFlightss.append(allArrivals.elementAt(j).toString());
		}		
		return allFlightss.toString();
	}

	public void save(String fileName) throws FileNotFoundException {
		File f=new File(fileName);
		PrintWriter pw= new PrintWriter(f);
		
		pw.println("hi");
		pw.print(allFlights.size()+"\n");
		

		for (int i = 0; i < allFlights.size(); i++) {
			allFlights.get(i).save(pw);
			}
		pw.close();
		}
	

	public String showByDestination(String desti) {
		
		StringBuffer str = new StringBuffer("");
		if(desti.equalsIgnoreCase("israel")) {
			for (int i = 0; i < allArrivals.size(); i++) 
				str.append(allArrivals.get(i).toString());
		}
		else {
			for (int i = 0; i < allDeparture.size(); i++) {
				if (allDeparture.get(i).getDestination().equalsIgnoreCase(desti))
					str.append(allDeparture.get(i).toString());
			
			}
		}
		return str.toString();
	}

	public String showByOrigin(String origin) {
		StringBuffer str = new StringBuffer("");
		if(origin.equalsIgnoreCase("israel")) {
			for (int i = 0; i < allDeparture.size(); i++) 
				str.append(allDeparture.get(i).toString());
		}
		else {
			for (int i = 0; i < allArrivals.capacity(); i++) {
				if (allArrivals.get(i).getDestination().equalsIgnoreCase(origin))
					str.append(allArrivals.get(i).toString());
			
			}
		}
		return str.toString();
	}

	public String findByDate(LocalDateTime startDate, LocalDateTime endDate) {
		StringBuffer str = new StringBuffer("");
		for (int i = 0; i < allFlights.size(); i++) {
			if ((allFlights.get(i).getDeparture().isAfter(startDate)
					&& allFlights.get(i).getDeparture().isBefore(endDate))||
					allFlights.get(i).getDeparture().isEqual(startDate)||
					allFlights.get(i).getDeparture().isEqual(endDate))
				str.append(allFlights.get(i).toString());
		}
		return str.toString();
	}

	public void importFlights(String fileName) throws FileNotFoundException {
		File f=new File(fileName);
		Scanner scanFile=new Scanner(f);
		
		int counter= Integer.parseInt(scanFile.nextLine());
		
		for (int i = 0; i <counter ; i++) {
			Flight newFlight = new Flight(scanFile, true);
			addFlight(newFlight);
			System.out.println(newFlight.toString());
		}
		scanFile.close();
		
		
	}
	public String toString() {
		StringBuffer str = new StringBuffer("");
		for (int i = 0; i < allFlights.size(); i++) {
			str.append(allFlights.get(i).toString());
		}
		return str.toString();
	}

}
