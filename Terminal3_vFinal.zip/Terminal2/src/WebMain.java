import java.time.LocalDateTime;
import Terminal3.Flight;
import Terminal3.TimeTable;

public class WebMain {

	public static void main(String[] args) {
		// http://localhost:8000/departures?outformat=html&flightNumber=ly315&destination=london&origin=israel&company=el-al&day1=20&month1=5&year1=2020&day2=20&month2=5&year2=2020&status=onTime
		// define dates

		LocalDateTime dateLondon = LocalDateTime.of(2020, 5, 20, 10, 10);
		LocalDateTime dateLondon2 = LocalDateTime.of(2020, 5, 20, 17, 15);
		LocalDateTime dateNewYork = LocalDateTime.of(2020, 5, 20, 0, 45);
		LocalDateTime dateNewYork2 = LocalDateTime.of(2020, 5, 20, 12, 45);
		LocalDateTime dateTelAviv = LocalDateTime.of(2020, 5, 20, 12, 50);
		LocalDateTime dateTelAviv2 = LocalDateTime.of(2020, 5, 20, 18, 13);
		LocalDateTime dateSpain = LocalDateTime.of(2020, 3, 20, 9, 13);
		LocalDateTime dateSpain2 = LocalDateTime.of(2020, 3, 20, 16, 13);
		LocalDateTime dateFrance = LocalDateTime.of(2020, 7, 20, 9, 13);
		LocalDateTime dateFrance2 = LocalDateTime.of(2020, 7, 20, 13, 13);

		// hardcoded flights
		Flight london = new Flight("ly315", "london", "israel", "el-al",
				dateLondon, dateLondon2, "onTime");
		Flight newYork = new Flight("ly001", "new York", "israel", "el-al",
				dateNewYork, dateNewYork2, "onTime");
		Flight telAviv = new Flight("ly215", "israel", "Paris", "el-al",
				dateTelAviv, dateTelAviv2, "onTime");
		Flight France = new Flight("ly756", "Paris", "israel", "el-al",
				dateFrance, dateFrance2, "onTime");
		Flight Barcelona = new Flight("ly333", "Barcelona", "israel", "el-al",
				dateSpain, dateSpain2, "onTime");
		TimeTable timeTable = new TimeTable();
		timeTable.addFlight(Barcelona);
		timeTable.addFlight(France);
		timeTable.addFlight(telAviv);
		timeTable.addFlight(newYork);
		timeTable.addFlight(london);
		// define parameters
		String flightNumber = "";
		String origin = "";
		String destination = "";
		String company = "";
		String status = "";
		int day1 = 1;
		int month1 = 1;
		int year1 = 2000;
		int hour1 = 0;
		int minute1 = 0;
		int day2 = 31;
		int month2 = 12;
		int year2 = 2020;
		int hour2 = 23;
		int minute2 = 59;

		boolean isEqual = false;
		boolean isHtml = (args.length > 0 && args[0].equalsIgnoreCase("html"));

		boolean isArrival = args.length > 1
				&& args[1].equalsIgnoreCase("arrivals");
		if (args.length > 1) {

			// define parameters in html
			// Flight london = new Flight("ly315", "london" , "israel" , "el-al"
			// , dateLondon , dateLondon2 , "onTime");
			flightNumber = args[2];
			destination = args[3];
			origin = args[4];
			company = args[5];
			day1 = Integer.parseInt(args[6]);
			month1 = Integer.parseInt(args[7]);
			year1 = Integer.parseInt(args[8]);
			day2 = Integer.parseInt(args[9]);
			month2 = Integer.parseInt(args[10]);
			year2 = Integer.parseInt(args[11]);
			status = args[12];

		}

		if (isHtml) {
			/*
			 * // define the design in html timeTable.findByDate(
			 * LocalDateTime.of(year1, month1, day1, hour1, minute1),
			 * LocalDateTime.of(year2, month2, day2, hour2, minute2));
			 */
			isEqual = false;
			if (isArrival) {
				System.out
						.println("<h2>All Arrivals: </h2>");
				System.out.println("<style>" + "table, th, td {"
						+ "  border: 2px solid black;"
						+ "border-collapse: collapse;" + "text-align: center;"
						+ "}" + "</style>");
				System.out.println("<table style=\"width:50%\">");
				System.out.println("<tbody>\r\n\n" + "<tr>\r\n"
						+ "<td><strong>Airline</strong></td>"
						+ "<td><strong>Destination</strong></td>\r\n"
						+ "<td><strong>Origin</strong></td>"
						+ "<td><strong>FlightNumber</strong></td>"
						+ "<td><strong>DepatureDate</strong></td>"
						+ "<td><strong>ArrivalDate</strong></td>"
						+ "<td><strong>Status</strong></td>");
				System.out.println(timeTable.showArrivalsFlights());
			} else {
				System.out
						.println("<h2>All Departures: </h2>");
				System.out.println("<style>" + "table, th, td {"
						+ "  border: 2px solid black;"
						+ "border-collapse: collapse;" + "text-align: center;"
						+ "}" + "</style>");
				System.out.println("<table style=\"width:50%\">");
				System.out.println("<tbody>\r\n" + "<tr>\r\n"
						+ "<td><strong>Airline</strong></td>"
						+ "<td><strong>Destination</strong></td>\r\n"
						+ "<td><strong>Origin</strong></td>"
						+ "<td><strong>FlightNumber</strong></td>"
						+ "<td><strong>DepatureDate</strong></td>"
						+ "<td><strong>ArrivalDate</strong></td>"
						+ "<td><strong>Status</strong></td>");
				System.out.println(timeTable.showDeparturesFlights());
			}

			for (int i = 0; i < timeTable.getAllFlights().size(); i++) {
				isEqual = company.equalsIgnoreCase(timeTable.getAllFlights()
						.get(i).getCompany())
						&& destination.equalsIgnoreCase(timeTable
								.getAllFlights().get(i).getDestination())
						&& origin.equalsIgnoreCase(timeTable.getAllFlights()
								.get(i).getOrigin())
						&& flightNumber.equalsIgnoreCase(timeTable
								.getAllFlights().get(i).getFlightNumber());

				if (isEqual) {
					System.out.println("</tr>\r\n" + "<tr>\r\n" + "<td>"
							+ timeTable.getAllFlights().get(i).getCompany()
							+ "</td>\r\n");
					System.out.println("<td>"
							+ timeTable.getAllFlights().get(i).getDestination()
							+ "</td>\r\n");
					System.out.println("<td>"
							+ timeTable.getAllFlights().get(i).getOrigin()
							+ "</td>\r\n");
					System.out.println("<td>"
							+ timeTable.getAllFlights().get(i)
									.getFlightNumber() + "</td>\r\n");

					System.out.println("<td>"
							+ timeTable.getAllFlights().get(i).getDeparture()
							+ "</td>\r\n");

					System.out.println("<td>"
							+ timeTable.getAllFlights().get(i).getArrival()
							+ "</td>\r\n");

				
					System.out.println("<td>"
							+ timeTable.getAllFlights().get(i).getStatus()
							+ "</td>\r\n");
				}
			}

		}
	}
}
