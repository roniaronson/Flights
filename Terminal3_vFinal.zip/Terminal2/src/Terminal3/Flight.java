package Terminal3;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.Scanner;



public class Flight {
	public enum eStatus {
		landed, onTime, Delay, Canceled};

	public enum Type {
		Arrival, Departure
	};

	private String flightNumber;

	private String destination;
	private String origin;
	private String company;
	private LocalDateTime arrival;
	private LocalDateTime departure;
	private eStatus status;
	private Type type;

	public Flight(String flightNumber, String destination, String origin, String company, LocalDateTime arrival,
			LocalDateTime departure, String status) {
		this.flightNumber = flightNumber;
		this.destination = destination;
		this.origin = origin;
		this.company = company;
		this.arrival = arrival;
		this.departure = departure;
		this.status = eStatus.valueOf(status);
		if (this.origin.equalsIgnoreCase("israel"))
			this.type = Type.valueOf("Departure");
		else if (this.destination.equalsIgnoreCase("israel"))
			this.type = Type.valueOf("Arrival");
		
	}

	public Flight(Scanner scan) {
		System.out.println("Enter flight number: ");
		this.flightNumber = scan.next();
		System.out.println("Enter destination: ");
		this.destination = scan.next();
		System.out.println("Enter origin: ");
		this.origin = scan.next();
		System.out.println("Enter company: ");
		this.company = scan.next();
		System.out.println("Enter your departure information: ");
		System.out.println("Enter year: ");
		int year = scan.nextInt();
		System.out.println("Enter month: ");
		int month = scan.nextInt();
		System.out.println("Enter day: ");
		int day = scan.nextInt();
		System.out.println("Enter hour: ");
		int hour = scan.nextInt();
		System.out.println("Enter minute: ");
		int minute = scan.nextInt();
		this.departure = LocalDateTime.of(year, month, day, hour, minute);
		System.out.println("Enter your arrival information: ");
		System.out.println("Enter year: ");
		year = scan.nextInt();
		System.out.println("Enter month: ");
		month = scan.nextInt();
		System.out.println("Enter day: ");
		day = scan.nextInt();
		System.out.println("Enter hour: ");
		hour = scan.nextInt();
		System.out.println("Enter minute: ");
		minute = scan.nextInt();
		this.arrival = LocalDateTime.of(year, month, day, hour, minute);
		System.out.println("Enter status: (landed, onTime, Delay, Canceled)");
		this.status = eStatus.valueOf(scan.next());
		if (this.origin.equalsIgnoreCase("israel"))
			this.type = Type.valueOf("Departure");
		else if (this.destination.equalsIgnoreCase("israel"))
			this.type = Type.valueOf("Arrival");
		
	}

	public Flight(Scanner scan, boolean t) {
		this.flightNumber = scan.nextLine();
		this.destination = scan.nextLine();
		this.origin = scan.nextLine();
		this.company = scan.nextLine();
		
		this.departure = LocalDateTime.parse(scan.nextLine());
		this.arrival = LocalDateTime.parse(scan.nextLine());
		// this.arrival=LocalDateTime.of(year, month, day, hour, minute);
		this.status = eStatus.valueOf(scan.nextLine());
		if (this.origin.equalsIgnoreCase("israel"))
			this.type = Type.valueOf("Departure");
		else if (this.destination.equalsIgnoreCase("israel"))
			this.type = Type.valueOf("Arrival");
		// else
		// throw new Exception("bla bla bla");
	}

	public void save(PrintWriter pw) throws FileNotFoundException {

		pw.print(this.flightNumber + "\n");
		pw.print(this.destination + "\n");
		pw.print(this.origin + "\n");
		pw.print(this.company + "\n");
		pw.print(this.arrival.toString() + "\n");
		pw.print(this.departure.toString() + "\n");
		pw.print(this.status.name() + "\n");

	}

	public String getType() {
		return this.type.name();
	}

	public LocalDateTime getArrival() {
		return this.arrival;
	}

	public LocalDateTime getDeparture() {
		return this.departure;
	}

	public String getDestination() {
		return destination;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public String getOrigin() {
		return origin;
	}

	public String getCompany() {
		return company;
	}

	public String getStatus() {
		return status.name();
	}

	public String toString() {
		return ("Flight Number: " + this.flightNumber + "\n" + "Destination: " + this.destination + "\n" + "Origin: "
				+ this.origin + "\n" + "Company: " + this.company + "\n" + "Arrival Time: " + this.arrival.toString()
				+ "\n" + "Departure Time: " + this.departure.toString() + "\n" + "Status: " + this.status.name()
				+ "\n");
	}
}
