package Terminal3;

import static org.junit.Assert.assertEquals;

import java.io.PrintWriter;
import java.time.LocalDateTime;

import org.junit.Test;

public class test {

	@Test
	public void statementTest1() throws Exception {
		Flight london = createFlight1();
		Flight newYork = createFlight2();
		PrintWriter pw = new PrintWriter("Terminal3.txt");
		TimeTable terminal3 = new TimeTable();
		terminal3.addFlight(newYork);
		terminal3.addFlight(london);
		// terminal3.save(pw);
		StringBuffer expectedResult = new StringBuffer();
		expectedResult.append("Flight Number: " + newYork.getFlightNumber() + "\n");
		expectedResult.append("Destination: " + newYork.getDestination() + "\n");
		expectedResult.append("Origin: " + newYork.getOrigin() + "\n");
		expectedResult.append("Company: " + newYork.getCompany() + "\n");
		expectedResult.append("Arrival Time: " + newYork.getArrival().toString() + "\n");
		expectedResult.append("Departure Time: " + newYork.getDeparture().toString() + "\n");
		expectedResult.append("Status: " + newYork.getStatus() + "\n");
		expectedResult.append("Flight Number: " + london.getFlightNumber() + "\n");
		expectedResult.append("Destination: " + london.getDestination() + "\n");
		expectedResult.append("Origin: " + london.getOrigin() + "\n");
		expectedResult.append("Company: " + london.getCompany() + "\n");
		expectedResult.append("Arrival Time: " + london.getArrival().toString() + "\n");
		expectedResult.append("Departure Time: " + london.getDeparture().toString() + "\n");
		expectedResult.append("Status: " + london.getStatus() + "\n");
		assertEquals(expectedResult.toString(), terminal3.showDeparturesFlights());
		// pw.close();
	}

	private Flight createFlight1() throws Exception {
		LocalDateTime londonDateArrival = LocalDateTime.of(2020, 5, 20, 10, 10);
		LocalDateTime londonDateDeparture = LocalDateTime.of(2020, 5, 20, 00, 10);
		Flight london = new Flight("LY315", "London", "Israel", "El-Al", londonDateArrival, londonDateDeparture,
				"onTime");
		return london;

	}

	private Flight createFlight2() throws Exception {
		LocalDateTime newYorkDateArrival = LocalDateTime.of(2020, 4, 20, 12, 10);
		LocalDateTime newYorkDateDeparture = LocalDateTime.of(2020, 4, 20, 00, 10);
		Flight newYork = new Flight("LY3001", "NewYork", "Israel", "El-Al", newYorkDateArrival, newYorkDateDeparture,
				"onTime");
		System.out.println(newYork.toString());
		return newYork;
	}
}
