import subprocess

from flask import request, Flask

app = Flask("my_app1")


@app.route("/departures")
def departures():
    return subprocess.check_output(["java", "-classpath",
                                    "C:/Users/תור/Desktop/Terminal3/bin", "WebMain",
                                    request.args.get('outformat'),
                                    "departures",
                                    request.args.get('flightNumber'),
                                    request.args.get('destination'),
                                    request.args.get('origin'),
                                    request.args.get('company'),
                                    request.args.get('day1'),
                                    request.args.get('month1'),
                                    request.args.get('year1'),
                                    request.args.get('year2'),
                                    request.args.get('month2'),
                                    request.args.get('day2'),
                                    request.args.get('status'), ])


@app.route("/arrivals")
def arrivals():
    return subprocess.check_output(["java", "-classpath",
                                    "C:/Users/תור/Desktop/Terminal3/bin", "WebMain",
                                    request.args.get('outformat'),
                                    "arrivals",
                                    request.args.get('flightNumber'),
                                    request.args.get('destination'),
                                    request.args.get('origin'),
                                    request.args.get('company'),
                                    request.args.get('day1'),
                                    request.args.get('month1'),
                                    request.args.get('year1'),
                                    request.args.get('year2'),
                                    request.args.get('month2'),
                                    request.args.get('day2'),
                                    request.args.get('status'), ])


app.run(port=8000, host="0.0.0.0")